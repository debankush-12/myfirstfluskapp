from flask import Flask, render_template, request, redirect, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///user.db"
app.config['SECRET_KEY'] = "mysecretkey"
db = SQLAlchemy(app)

class User(db.Model):
    s_no = db.Column(db.Integer, primary_key=True)
    patient_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False, unique=True) 
    password = db.Column(db.String(256), nullable=False) 

class Appointment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_name = db.Column(db.String(100), nullable=False)
    doctor_name = db.Column(db.String(100), nullable=False)
    date = db.Column(db.String(50), nullable=False)
    condition = db.Column(db.String(500), nullable=False) 


@app.route('/')
def home():
    return render_template('index.html')

@app.route('/signup', methods=["GET", "POST"]) 
def signup():
    if request.method == 'POST':
        patient_name = request.form['patient_name']
        email = request.form['email']
        password = request.form['password']
        hashed_password = generate_password_hash(password)
        
        try:
            new_user = User(patient_name=patient_name, email=email, password=hashed_password)
            db.session.add(new_user)
            db.session.commit() 
            return redirect('/login')
        except:
            return "Email already exists!"
            
    return render_template('signup.html') 

@app.route('/login', methods=["GET", "POST"]) 
def login():
    error = None 
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        user = User.query.filter_by(email=email).first()
        
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.s_no 
            session['role'] = 'patient'
            return redirect('/appointment') 
        else:
            error = "Invalid Email or Password."

    return render_template('login.html', error=error)

@app.route('/doctor_login', methods=["GET", "POST"])
def doctor_login():
    error = None
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        if email == "doctor@hospital.com" and password == "doctor123":
            session['role'] = 'doctor' 
            return redirect('/dashboard') 
        else:
            error = "Invalid Doctor Credentials"
            
    return render_template('doctor_login.html', error=error)

@app.route('/dashboard')
def dashboard():
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        return render_template('dashboard.html', user=user)
    return redirect('/login')

# @app.route('/appointment', methods=["GET", "POST"])
# def appointment():
#     if 'user_id' not in session:
#         return redirect('/login')
    
#     current_user = User.query.get(session['user_id'])

#     if request.method == "POST":
#         doctor_name = request.form['doctor']
#         date = request.form['date']
#         condition = request.form['condition']
        
#         new_appointment = Appointment(
#             patient_name=current_user.patient_name,
#             doctor_name=doctor_name,
#             date=date,
#             condition=condition
#         )
#         db.session.add(new_appointment)
#         db.session.commit()
        
#         return redirect('/appointment')
            
#     my_appointments = Appointment.query.filter_by(patient_name=current_user.patient_name).all()
#     return render_template('appointment.html', my_appointments=my_appointments)
@app.route('/appointment', methods=["GET", "POST"])
def appointment():
    if 'user_id' not in session:
        return redirect('/login')
    
    current_user = User.query.get(session['user_id'])

    if request.method == "POST":
        doctor_name = request.form['doctor']
        date = request.form['date']
        condition = request.form['condition']
        
        new_appointment = Appointment(
            patient_name=current_user.patient_name,
            doctor_name=doctor_name,
            date=date,
            condition=condition
        )
        db.session.add(new_appointment)
        db.session.commit()
        
        return redirect('/appointment')
            
    my_appointments = Appointment.query.filter_by(patient_name=current_user.patient_name).all()
    
    return render_template(
        'appointment.html', 
        my_appointments=my_appointments,
        bills=bills
    )

bills = []
@app.route("/billing", methods=["POST"])
def billing():
    patient_name = request.form["patient_name"]
    billing_date = request.form["billing_date"]
    fee = request.form["fee"]
    payment_method = request.form["payment_method"]

    bills.append({
        "patient_name": patient_name,
        "billing_date": billing_date,
        "fee": fee,
        "payment_method": payment_method
    })

    return redirect("/appointment")

@app.route('/doctors')
def doctors():
    return render_template('doctors.html')

@app.route('/patients')
def patients():
    if session.get('role') != 'doctor':
        return redirect('/doctor_login')

    all_users = User.query.all()
    all_appointments = Appointment.query.all()
    
    patient_info_map = {}
    for appt in all_appointments:
        patient_info_map[appt.patient_name] = {
            'doctor': appt.doctor_name,
            'condition': appt.condition
        }
        
    return render_template('patients.html', all_users=all_users, patient_info_map=patient_info_map)

@app.route('/logout')
def logout():
    session.clear() 
    return redirect('/login')

if __name__ == "__main__":
    with app.app_context():
        db.create_all() 
    app.run(debug=True)
