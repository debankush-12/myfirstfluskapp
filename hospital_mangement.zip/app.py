from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_123'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///hospital.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# --- A. DATABASE MODELS ---

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), nullable=False) # 'admin', 'doctor', 'patient'

class DoctorDetail(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    specialization = db.Column(db.String(100), nullable=False)
    user = db.relationship('User', backref=db.backref('doctor_detail', uselist=False))

class Appointment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    date = db.Column(db.String(20), nullable=False)
    time = db.Column(db.String(20), nullable=False)
    symptoms = db.Column(db.Text, nullable=False)
    
    patient = db.relationship('User', foreign_keys=[patient_id], backref='appointments_made')
    doctor = db.relationship('User', foreign_keys=[doctor_id], backref='appointments_received')

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# --- DB INIT & SEEDING ---
def init_db():
    with app.app_context():
        db.create_all()
        
        # 1. Create Admin
        if not User.query.filter_by(email='admin@gmail.com').first():
            admin = User(name='Super Admin', email='admin@gmail.com', 
                         password=generate_password_hash('admin123'), role='admin')
            db.session.add(admin)

        # 2. Define the EXACT list of Doctors you want
        doctors_list = [
            # Cardiology
            {"name": "Dr. Devi Prasad Shetty", "spec": "Cardiology"},
            {"name": "Dr. Naresh Trehan", "spec": "Cardiology"},
            
            # Neurology (The ones you asked to add)
            {"name": "Dr. B. K. Misra", "spec": "Neurology & Neurosurgery"},
            {"name": "Dr. Ashok Panagariya", "spec": "Neurology & Neurosurgery"},
            
            # General Physicians
            {"name": "Dr. Bidhan Chandra Roy", "spec": "General Physicians"},
            {"name": "Dr. M. K. Mani", "spec": "General Physicians"},
            
            # Orthopedics
            {"name": "Dr. K. H. Sancheti", "spec": "Orthopedics"},
            {"name": "Dr. Ashok Rajgopal", "spec": "Orthopedics"},
            
            # Ophthalmology
            {"name": "Dr. G. Venkataswamy", "spec": "Ophthalmology"},
            {"name": "Dr. S. Natarajan", "spec": "Ophthalmology"},
            
            # Gynecology
            {"name": "Dr. Indira Hinduja", "spec": "Gynecology & Obstetrics"},
            {"name": "Dr. Kamini Rao", "spec": "Gynecology & Obstetrics"},
            
            # Oncology
            {"name": "Dr. V. Shanta", "spec": "Oncology"},
            {"name": "Dr. Suresh Advani", "spec": "Oncology"},
            
            # Pediatrics
            {"name": "Dr. Meharban Singh", "spec": "Pediatrics"},
            {"name": "Dr. Nandita Chatterjee", "spec": "Pediatrics"},
            
            # Ayurveda
            {"name": "Dr. P. K. Warrier", "spec": "Ayurveda"},
            {"name": "Dr. Vasant Lad", "spec": "Ayurveda"},
            
            # Radiology
            {"name": "Dr. Arjun Kalyanpur", "spec": "Radiology"},
            {"name": "Dr. Bhavin Jankharia", "spec": "Radiology"},
            
            # Genetics
            {"name": "Dr. M. S. Swaminathan", "spec": "Medical Research & Genetics"},
            {"name": "Dr. Lalji Singh", "spec": "Medical Research & Genetics"},
            
            # Dermatology
            {"name": "Dr. Rekha Sheth", "spec": "Dermatology"},
            {"name": "Dr. D. M. Thappa", "spec": "Dermatology"},
            
            # Psychiatry
            {"name": "Dr. N. N. Wig", "spec": "Psychiatry & Mental Health"},
            {"name": "Dr. Vidya Sagar", "spec": "Psychiatry & Mental Health"},
            
            # Infectious Diseases
            {"name": "Dr. Soumya Swaminathan", "spec": "Infectious Diseases"},
            {"name": "Dr. T. Jacob John", "spec": "Infectious Diseases"},
            
            # Dentistry
            {"name": "Dr. Sandesh Mayekar", "spec": "Dentistry"},
            {"name": "Dr. Ratnadeep Patil", "spec": "Dentistry"}
        ]

        # 3. Loop through list and add to DB
        for doc in doctors_list:
            # Generate email: e.g., b.k.misra@hospital.com
            safe_name = doc["name"].lower().replace("dr. ", "").replace(" ", ".")
            email = f"{safe_name}@hospital.com"
            
            if not User.query.filter_by(email=email).first():
                new_doc = User(
                    name=doc["name"], 
                    email=email, 
                    password=generate_password_hash('password123'),
                    role='doctor'
                )
                db.session.add(new_doc)
                db.session.commit() 
                
                detail = DoctorDetail(user_id=new_doc.id, specialization=doc["spec"])
                db.session.add(detail)

        # 4. (Optional) Keep the main "Dr. House" as a default demo if you want, or remove this block
        if not User.query.filter_by(email='doctor@gmail.com').first():
            doc_user = User(name='Dr. House', email='doctor@gmail.com', 
                            password=generate_password_hash('doctor123'), role='doctor')
            db.session.add(doc_user)
            db.session.commit()
            db.session.add(DoctorDetail(user_id=doc_user.id, specialization='Cardiology'))

        db.session.commit()
# --- B. ROUTES ---
@app.route('/')
def home():
    # If the user is ALREADY logged in, send them to their dashboard automatically
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            return redirect(url_for('admin_dashboard'))
        elif current_user.role == 'doctor':
            return redirect(url_for('doctor_dashboard'))
        else:
            return redirect(url_for('patient_dashboard'))
            
    # If NOT logged in, show the Landing Page first
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password, password):
            login_user(user)
            if user.role == 'admin':
                return redirect(url_for('admin_dashboard'))
            elif user.role == 'doctor':
                return redirect(url_for('doctor_dashboard'))
            else:
                return redirect(url_for('patient_dashboard'))
        else:
            flash('Invalid Email or Password', 'danger')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']

        if User.query.filter_by(email=email).first():
            flash('Email already registered', 'warning')
            return redirect(url_for('register'))

        # Hardcoded prevention: Cannot register as doctor or admin email
        if email in ['admin@gmail.com', 'doctor@gmail.com']:
            flash('Cannot register as Admin or Staff.', 'danger')
            return redirect(url_for('register'))

        new_user = User(name=name, email=email, password=generate_password_hash(password), role='patient')
        db.session.add(new_user)
        db.session.commit()
        flash('Registration Successful! Please Login.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# --- DASHBOARDS ---

@app.route('/patient/dashboard')
@login_required
def patient_dashboard():
    if current_user.role != 'patient': return redirect(url_for('login'))
    
    # Get all doctors joined with their details
    doctors = db.session.query(User, DoctorDetail).join(DoctorDetail, User.id == DoctorDetail.user_id).all()
    
    # Organize by specialization
    specs = {}
    for user, detail in doctors:
        if detail.specialization not in specs:
            specs[detail.specialization] = []
        specs[detail.specialization].append(user)

    my_appointments = Appointment.query.filter_by(patient_id=current_user.id).all()
    
    return render_template('patient_dashboard.html', specs=specs, appointments=my_appointments)

@app.route('/book/<int:doctor_id>', methods=['GET', 'POST'])
@login_required
def book_appointment(doctor_id):
    if current_user.role != 'patient': return redirect(url_for('login'))
    
    doctor = User.query.get_or_404(doctor_id)
    
    if request.method == 'POST':
        date = request.form['date']
        time = request.form['time']
        symptoms = request.form['symptoms']

        # Prevent Double Booking
        existing = Appointment.query.filter_by(doctor_id=doctor_id, date=date, time=time).first()
        if existing:
            flash('This time slot is already booked for this doctor.', 'danger')
        else:
            new_appt = Appointment(patient_id=current_user.id, doctor_id=doctor_id, 
                                   date=date, time=time, symptoms=symptoms)
            db.session.add(new_appt)
            db.session.commit()
            flash('Appointment Booked Successfully!', 'success')
            return redirect(url_for('patient_dashboard'))
            
    return render_template('appointment_form.html', doctor=doctor)

@app.route('/doctor/dashboard')
@login_required
def doctor_dashboard():
    if current_user.role != 'doctor': return redirect(url_for('login'))
    
    # Get appointments for this doctor
    appointments = Appointment.query.filter_by(doctor_id=current_user.id).all()
    return render_template('doctor_dashboard.html', appointments=appointments)

@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    if current_user.role != 'admin': return redirect(url_for('login'))
    
    total_docs = User.query.filter_by(role='doctor').count()
    total_patients = User.query.filter_by(role='patient').count()
    total_appts = Appointment.query.count()
    
    appointments = Appointment.query.all()
    doctors = User.query.filter_by(role='doctor').all()
    patients = User.query.filter_by(role='patient').all()
    
    return render_template('admin_dashboard.html', 
                           total_docs=total_docs, total_patients=total_patients, 
                           total_appts=total_appts, appointments=appointments,
                           doctors=doctors, patients=patients)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)